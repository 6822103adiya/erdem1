# Face-Recognition-based-attendance-system-
Simple code to mark attendance using facial recognition by OpenCv and Face-recognition module
